<?php

$host = "sql112.infinityfree.com";
$db   = "if0_41395510_account";
$user = "if0_41395510";
$pass = "DQ8QLbP6NQOz";

try {

$pdo = new PDO(
"mysql:host=$host;dbname=$db;charset=utf8mb4",
$user,
$pass
);

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch(PDOException $e){

die("Database connection failed");

}