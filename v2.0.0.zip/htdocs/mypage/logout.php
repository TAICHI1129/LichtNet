<?php
session_start();

/* セッション全削除 */
$_SESSION = [];
session_destroy();

/* クッキーも削除（念のため） */
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

/* ログイン画面へ */
header("Location: index.php");
exit;