<?php
session_start();

define("SECRET_KEY","LICHTNET_SECRET_KEY");

/* 既にログイン済み */
if(isset($_SESSION["user"])){
    $user = $_SESSION["user"];
}else{

    $token = $_POST["token"] ?? "";

    /* トークン無し → ログイン画面 */
    if(!$token){
        ?>
        <!DOCTYPE html>
        <html>
        <head>
        <meta charset="UTF-8">
        <title>Login Required</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
        body {
            text-align: center;
            margin-top: 100px;
            background: #111;
            color: #fff;
            font-family: sans-serif;
        }
        .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background: #ff5555;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }
        </style>
        </head>
        <body>

        <h2>ログインが必要です</h2>

        <a href="https://lichtnet.ct.ws/login.php?from=<?=urlencode("https://lichtnet.ct.ws/callback.php")?>"
           class="btn">
           Lichtnetでログイン
        </a>

        </body>
        </html>
        <?php
        exit;
    }

    /* トークン検証 */
    $parts = explode(".", $token);
    if(count($parts) !== 2){
        die("トークン形式が不正です");
    }

    list($b64, $sign) = $parts;

    $expected = hash_hmac("sha256", $b64, SECRET_KEY);
    if(!hash_equals($expected, $sign)){
        die("不正なトークンです");
    }

    $data = json_decode(base64_decode($b64), true);
    if(!$data){
        die("データの復号に失敗しました");
    }

    if(!isset($data["exp"]) || $data["exp"] < time()){
        die("トークンの有効期限が切れています");
    }

    /* セッション保存 */
    $_SESSION["user"] = [
        "email" => $data["email"],
        "username" => $data["username"]
    ];

    $user = $_SESSION["user"];
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Lichtnet My Page</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body{
    font-family:sans-serif;
    background:#111;
    color:#fff;
    text-align:center;
    padding-top:50px;
}
.card{
    background:#1e1e1e;
    padding:30px;
    border-radius:10px;
    width:300px;
    max-width:90%;
    margin:auto;
    text-align:center;
}
.btn{
    display:inline-block;
    margin-top:20px;
    padding:10px 15px;
    background:#ff5555;
    color:#fff;
    text-decoration:none;
    border-radius:5px;
}
</style>
</head>
<body>

<div class="card">

<h1>My Page</h1>

<!-- 編集ここから -->
    
<p>Welcome, <?=htmlspecialchars($user["username"])?>!</p>
<p>Email: <?=htmlspecialchars($user["email"])?></p>
    
<!-- 編集ここまで -->

<div style="text-align:center;">
    <a href="logout.php" class="btn">Logout</a>
</div>

</div>

</body>
</html>