<?php
session_start();

define("SECRET_KEY","LICHTNET_SECRET_KEY");

/* --- DB接続 --- */
$host = 'sql112.infinityfree.com';
$db   = 'if0_41395510_account';
$user_db = 'if0_41395510';
$pass_db = 'DQ8QLbP6NQOz';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

try {
    $pdo = new PDO($dsn, $user_db, $pass_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("DB接続失敗: " . $e->getMessage());
}

/* --- ログインチェック --- */
if(isset($_SESSION["user"])){
    $user = $_SESSION["user"];
} else {
    $token = $_POST["token"] ?? "";
    if(!$token){
        ?>
        <!DOCTYPE html>
        <html>
        <head>
        <meta charset="UTF-8">
        <title>Login Required</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
        body { text-align:center; margin-top:100px; background:#111; color:#fff; font-family:sans-serif; }
        .btn { display:inline-block; margin-top:20px; padding:10px 15px; background:#ff5555; color:#fff; text-decoration:none; border-radius:5px; }
        </style>
        </head>
        <body>
        <h2>Login is required</h2>
        <a href="https://lichtnet.ct.ws/login.php?from=<?=urlencode("https://lichtnet.ct.ws/callback.php")?>">
    <img src="https://lichtnet.ct.ws/img/LoginBtnEn.png" alt="Login with Lichtnet" width="300" height="200">
        </a>
        </body>
        </html>
        <?php
        exit;
    }

    /* --- トークン検証 --- */
    $parts = explode(".", $token);
    if(count($parts) !== 2) die("The token format is invalid.");

    list($b64, $sign) = $parts;
    $expected = hash_hmac("sha256", $b64, SECRET_KEY);
    if(!hash_equals($expected, $sign)) die("Invalid token");

    $data = json_decode(base64_decode($b64), true);
    if(!$data) die("Failed to decrypt the data");
    if(!isset($data["exp"]) || $data["exp"] < time()) die("The token has expired");

    /* --- セッション保存 --- */
    $_SESSION["user"] = [
        "email" => $data["email"],
        "username" => $data["username"]
    ];
    $user = $_SESSION["user"];
}

/* --- 更新処理 --- */
$success_msg = "";
$error_msg = "";

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])){
    $new_email = trim($_POST['email'] ?? '');
    $new_username = trim($_POST['username'] ?? '');
    $new_password = $_POST['password'] ?? '';

    // 使用禁止文字チェック（完全版）
    if(!preg_match('/^[a-zA-Z0-9._@-]+$/', $new_email)){
        $error_msg .= "Email contains invalid characters.<br>";
    }

    if(!preg_match('/^[a-zA-Z0-9_-]+$/', $new_username)){
        $error_msg .= "Username contains invalid characters.<br>";
    }

    if($new_email && $new_username && !$error_msg){
        try {
            // メール重複チェック
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email=:email AND email != :current_email");
            $stmt->execute([
                'email' => $new_email,
                'current_email' => $user['email']
            ]);
            if($stmt->fetchColumn() > 0){
                $error_msg .= "Email is already taken by another user.<br>";
            }

            // ユーザ名重複チェック
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username=:username AND email != :current_email");
            $stmt->execute([
                'username' => $new_username,
                'current_email' => $user['email']
            ]);
            if($stmt->fetchColumn() > 0){
                $error_msg .= "Username is already taken by another user.<br>";
            }

            // 変更がない場合も警告
            if($new_email === $user['email'] && $new_username === $user['username'] && !$new_password){
                $error_msg .= "No changes detected.<br>";
            }

            if(!$error_msg){
                $sql = "UPDATE users SET email=:email, username=:username";
                $params = [
                    'email' => $new_email,
                    'username' => $new_username,
                    'email_old' => $user['email']
                ];

                if($new_password){
                    $sql .= ", password=:password";
                    $params['password'] = password_hash($new_password, PASSWORD_DEFAULT);
                }

                $sql .= " WHERE email=:email_old";

                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);

                // セッション更新
                $_SESSION['user']['email'] = $new_email;
                $_SESSION['user']['username'] = $new_username;
                $user = $_SESSION['user'];

                $success_msg = "Information has been updated";
            }
        } catch (PDOException $e){
            $error_msg = "Failed to update: " . $e->getMessage();
        }
    } elseif(!$error_msg) {
        $error_msg = "Email and username are required.<br>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Lichtnet My Page</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body{font-family:sans-serif;background:#111;color:#fff;text-align:center;padding-top:50px;}
.card{background:#1e1e1e;padding:30px;border-radius:10px;width:300px;max-width:90%;margin:auto;text-align:center;}
.btn{display:inline-block;margin-top:20px;padding:10px 15px;background:#ff5555;color:#fff;text-decoration:none;border-radius:5px;}
input{margin:5px 0;padding:8px;width:90%;border-radius:5px;border:none;}
.success{color:#0f0;margin-top:10px;}
.error{color:#f55;margin-top:10px;}
</style>
</head>
<body>

<div class="card">
<h1>My Page</h1>

<p>Welcome, <?=htmlspecialchars($user["username"])?>!</p>
<p>Email: <?=htmlspecialchars($user["email"])?></p>

<?php if($success_msg): ?>
<p class="success"><?=htmlspecialchars($success_msg)?></p>
<?php endif; ?>

<?php if($error_msg): ?>
<p class="error"><?= $error_msg ?></p>
<?php endif; ?>

<form method="post">
    <input type="text" name="username" placeholder="Username" value="<?=htmlspecialchars($user['username'])?>" required><br>
    <input type="email" name="email" placeholder="Email" value="<?=htmlspecialchars($user['email'])?>" required><br>
    <input type="password" name="password" placeholder="New Password (leave blank to keep)"><br>
    <button type="submit" name="update" class="btn">Update</button>
</form>

<div style="text-align:center;">
    <a href="logout.php" class="btn">Logout</a>
</div>

</div>

</body>
</html>