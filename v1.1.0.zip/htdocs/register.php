<?php
require "db.php";

$msg="";
$from = $_POST["from"] ?? $_GET["from"] ?? "";
$lang = $_GET["lang"] ?? "ja";

$messages=[
"ja"=>[
"email"=>"メール",
"password"=>"パスワード",
"register"=>"登録",
"switch"=>"ログインはこちら",
"privacy"=>"サービスに情報を送信することがあります。<a href='#'>利用規約</a>、<a href='#'>プライバシーポリシー</a>を確認してください。"
],
"en"=>[
"email"=>"Email",
"password"=>"Password",
"register"=>"Register",
"switch"=>"Login",
"privacy"=>"We may send information to the service. Please check the <a href='#'>Terms of Service</a> and <a href='#'>Privacy Policy</a>."
],
"es"=>[
"email"=>"Correo",
"password"=>"Contraseña",
"register"=>"Crear cuenta",
"switch"=>"Iniciar sesión",
"privacy"=>"Podemos enviar información al servicio. Consulte los <a href='#'>Términos de servicio</a> y la <a href='#'>Política de privacidad</a>."
],
"zh"=>[
"email"=>"邮箱",
"password"=>"密码",
"register"=>"创建账号",
"switch"=>"登录",
"privacy"=>"我们可能会向服务发送信息。请查看<a href='#'>服务条款</a>和<a href='#'>隐私政策</a>。"
]
];

if($_SERVER["REQUEST_METHOD"]==="POST"){

$email = $_POST["email"] ?? "";
$password = $_POST["password"] ?? "";

$errors = [];

// メールチェック
if(strlen($email) === 0){
    $errors[] = "メールが入力されていません";
}elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
    $errors[] = "メール形式が不正です";
}

// パスワードチェック
if(strlen($password) === 0){
    $errors[] = "パスワードが入力されていません";
}elseif(strlen($password) < 6){
    $errors[] = "パスワードは6文字以上必要です";
}

if(empty($errors)){

    $hash=password_hash($password,PASSWORD_DEFAULT);

    try{

        $stmt=$pdo->prepare("INSERT INTO users(email,password) VALUES (?,?)");
        $stmt->execute([$email,$hash]);

        $msg="登録成功";

    }catch(PDOException $e){

        if(strpos($e->getMessage(),"Duplicate") !== false){
            $msg="このメールは既に登録されています";
        }else{
            $msg="データベースエラー: ".$e->getMessage();
        }

    }

}else{

    $msg = implode("<br>", $errors);

    // デバッグ情報（必要なら消してOK）
    $msg .= "<br><small>DEBUG: email=".htmlspecialchars($email)." / pass_len=".strlen($password)."</small>";

}

}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Lichtnet Register</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="card">

<div class="lang-select">
<form method="get">
<select name="lang" onchange="this.form.submit()">
<option value="ja" <?=$lang=="ja"?"selected":""?>>日本語</option>
<option value="en" <?=$lang=="en"?"selected":""?>>English</option>
<option value="es" <?=$lang=="es"?"selected":""?>>Español</option>
<option value="zh" <?=$lang=="zh"?"selected":""?>>中文</option>
</select>
<input type="hidden" name="from" value="<?=htmlspecialchars($from)?>">
</form>
</div>

<h1>Lichtnet</h1>

<form method="POST">
<input type="hidden" name="from" value="<?=htmlspecialchars($from)?>">

<input type="email"
name="email"
placeholder="<?=$messages[$lang]["email"]?>"
required>

<input type="password"
name="password"
placeholder="<?=$messages[$lang]["password"]?>"
required>

<button><?=$messages[$lang]["register"]?></button>

</form>

<div class="switch">
<a href="login.php?from=<?=urlencode($from)?>">
<?=$messages[$lang]["switch"]?>
</a>
</div>

<div class="msg"><?=$msg?></div>

<div class="privacy">
<?=$messages[$lang]["privacy"]?>
</div>

</div>

</body>
</html>